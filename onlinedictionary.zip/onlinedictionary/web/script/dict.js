/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(function () {


    $(document).on("click", "#btnLookup", function () {
        var search = $("#textinput").val();
        $.ajax({
            url: "dict",
            data: {
                "search": search
            },
            type: "GET",
            success: function (response) {
                var dts = $.parseJSON(response);
                $("#resultHere").nextAll().remove();

                if (dts.length === 0) {
                    $("p").last().after("<h3>Word not found: <em>" + search + "</em></h3>");
                } else {
                    $("p").last().after("<h3>Search Results for <em>" + search + "</em></h3>");
                    for (i = 0; i < dts.length; i += 1) {

                        if (i === 0) {
                            $("h3").last().after($("<h3>").text("Word type ").append($("<em>").text(dts[i].wordtype)));
                            $("h3").last().after("<p><em>" + (i + 1) + "</em> " + dts[i].definition + "</p>");
                        } else if (dts[i - 1].wordtype === dts[i].wordtype) {
                            $("p").last().after("<p><em>" + (i + 1) + "</em> " + dts[i].definition + "</p>");
                        } else {

                            $("p").last().after($("<h3>").text("Word type ").append($("<em>").text(dts[i].wordtype)));
                            $("h3").last().after("<p><em>" + (i + 1) + "</em> " + dts[i].definition + "</p>");
                        }
                    }
                }
            }
        });

    });
});