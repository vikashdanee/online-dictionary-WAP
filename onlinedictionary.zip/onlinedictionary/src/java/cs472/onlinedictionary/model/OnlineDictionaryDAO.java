/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs472.onlinedictionary.model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import cs472.onlinedictionary.dbaccess.dbConnection;

/**
 *
 * @author Vikas
 */
public class OnlineDictionaryDAO {

    dbConnection cm;
    Connection con;
    Statement stmt;
    ResultSet rs;

    public OnlineDictionaryDAO() {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public List<Entries> SearchWord(String word) {
        try {
            List<Entries> entriesList;

            String sql = "SELECT * FROM entries.entries where word = '" + word + "'";
            stmt = con.createStatement();

            rs = stmt.executeQuery(sql);

            if (rs == null) {

                return null;
            }

            entriesList = new ArrayList<>();
            while (rs.next()) {
                Entries f = new Entries(rs.getString("word").trim(), rs.getString("wordtype").trim(),
                        rs.getString("definition").trim());
                entriesList.add(f);

            }
            return entriesList;
        } catch (Exception e) {

            e.printStackTrace();
        }
        return null;
    }
}
