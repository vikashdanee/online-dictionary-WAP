/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs472.onlinedictionary.model;

/**
 *
 * @author Vikas
 */
public class Entries {

    public String word;
    public String wordtype;
    public String definition;

    public Entries(String w, String wt, String d) {
        this.word = w;
        this.wordtype = wt;
        this.definition = d;
    }

}
